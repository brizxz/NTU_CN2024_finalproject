# 計網PHASE-1 README
## 如何執行
1. 首先使用 `make clean` 清除執行檔
2. 使用 `make` 編譯檔案
3. 執行 `./server` 和 `./client` 分別執行client和server
4. 根據你所輸入的功能進行對應的操作